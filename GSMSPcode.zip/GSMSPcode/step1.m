% Select the file to analyze

FileName = 'GSMSP_20070204_robert_dbsrx_953.6MHz_128.cfile';
SampleRate = 500000;

%FileName = 'GSMSP_20070204_robert_dbsrx_941.0MHz_128.cfile';
%SampleRate = 500000;

%FileName = 'GSMSP_20070204_robert_dbsrx_953.6MHz_64.cfile';
%SampleRate = 1000000;

% A few handy constants

FilterBandWidth = 100000;
SymbolRate = 270833;
Interpolation = 13;

% Load file

r = read_complex_binary(FileName);

% Low pass filter

filt = fir1(40, 2*FilterBandWidth/SampleRate);
r = conv(r,filt);

% Resample to 1x bit rate for faster Frequency Correction Burst search

Decimation = round(SampleRate*Interpolation/SymbolRate);
t = resample(r,Interpolation,Decimation);

% Find first frequency correction burst in the file

bcch_start = find_fcch(t,1,15000)

% Calculate frequency offset

freq_offset = calc_freq_offset(t,bcch_start,1);

frequency_offset_before_Hz = freq_offset * SymbolRate / (2 * pi)

% Resample to 4x GSM bit rate for further processing

oversampling = 4;
Decimation = round(SampleRate*Interpolation/(oversampling*SymbolRate));
r = resample(r,Interpolation,Decimation);
bcch_start = bcch_start * oversampling;

% Correct the frequency of the whole vector

r = xlat_freq(r, freq_offset / oversampling);

% Check offset once more

freq_offset = calc_freq_offset(r, bcch_start, oversampling);
frequency_offset_after_Hz = freq_offset * SymbolRate / (2 * pi)
