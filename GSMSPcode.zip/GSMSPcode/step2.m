first_data_burst_start = 0;

for n=(bcch_start+5000):50000:length(r)
    
  sync_burst_start = find_sch(r,n,n+599)
  [BCC, PLM, FN] = demod_sb(r',n)
  
  if first_data_burst_start == 0
      first_data_burst_start = sync_burst_start + 5000;
      first_data_burst_frame_number = FN + 1;
  end
  
  pause
  
end



