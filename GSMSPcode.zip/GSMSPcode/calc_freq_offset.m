function frequency_offset_rads = calc_freq_offset(s, bcch_start, OSR)

SR = 270833; %sampling frequency
GUARD = 6 * OSR;
LENGTH = 148 * OSR - 2 * GUARD;


t = s(bcch_start+GUARD:bcch_start+GUARD+LENGTH);
L = length(t);
da = angle(t(1:L-1) .* conj(t(2:L)));
v = mean(da);

subplot(212);
%abscissa = GUARD:148-GUARD-1;
abscissa = 1:length(da);
plot(abscissa,-(pi/2)-da);
hold on

frequency_offset_rads = -(pi/2/OSR) - v

plot(abscissa,ones(size(abscissa))*frequency_offset_rads,'k:');
xlabel('sample number')
ylabel('digital frequency (rad)')
print -depsc bcch.eps
pause

