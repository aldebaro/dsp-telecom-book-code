
function sch_start = find_sch(r, start, stop)

OSR = 4;

a = r(start:start+610);

SYNCBITS = [1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1];
syncseq = T_SEQ_gen(SYNCBITS);

%syncseq = syncseq(19:44);

subplot(3,1,1);
L = length(syncseq);
da = angle(syncseq(1:L-1) .* conj(syncseq(2:L)));
sa = cumsum(da);
plot(sa);
title('MSK representation of sync seq');
axis([0 150 -20 20]);

subplot(3,1,2);
L = length(a);
ea = angle(a(1:L-1) .* conj(a(2:L)));
fa = cumsum(ea);
plot(fa);
title('Received frame');
axis([0 600 -20 20]);

%figure:plotframe2(a);

for n = 1:(length(a)-OSR*length(syncseq))
  chan_est(n)= syncseq * conj(a(n:OSR:n+(length(syncseq)-1)*OSR));
end


subplot(3,1,3);
plot(abs(chan_est));
title('Correlation');
axis([0 600 0 2e5]);

[peak_corr_value, location] = max(abs(chan_est));

sch_start = location + start - 168;

pause
  
  
  