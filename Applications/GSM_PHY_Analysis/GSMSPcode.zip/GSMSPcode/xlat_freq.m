function Y = xlat_freq(X, offset)

O = cos(offset) - j * sin(offset);
TO = 1;
Y = X;

for i = 1 : length(X)
    TO = TO * O;
    Y(i) = X(i) * TO;
end