function bcch_start = find_fcch(s, start, stop)

r = s(start:stop);

OSR = 1; %oversampling
BL = 142*OSR; %?
TB = 3*OSR;
FL = 2 * TB + BL; %148
PLOTEXTRA = 25;

L = length(r);
da = angle(r(1:L-1) .* conj(r(2:L)));
%equivalent to
%da2 = - filter([1 -1],1,angle(r));
%da2(1)=[];
%but this second method has problems with the 360 degrees wrap
sa = cumsum(da);

for i = 1 : (L-BL-1)
    low  = min(da(i:i+BL-1));
    high = max(da(i:i+BL-1));
    df(i) = high - low;
end

[x, i] = min(df);

if 0
    subplot(2,1,1);
    plot(df);
    hold on;
    plot(i,x,'x','markersize',20);

    hold off;
    subplot(2,1,2);
    plot(sa);
    pause
end

clf
subplot(211);
N=10000; temp = df(N:end);
Fs = 270833; %sampling frequency
plot([0:length(temp)-1]/Fs,temp);
hold on;
plot((i-N)/Fs,x,'kx','markersize',20);
title('Location of a burst for frequency correction');
xlabel('time (s)');
ylabel('max freq. - min freq. (rad)');

if x < 1
    bcch_start = i + start - TB;
    if 0 %ak, not plotting
        plotframe2(s(bcch_start-PLOTEXTRA:bcch_start+FL+PLOTEXTRA));
    end
else
    bcch_start = -1;
end